var app = angular.module('CurrencyApp', []);
app.controller('Currencyctrl', function ($scope, $http,$window) {
  $scope.FrmCurrency = ["CAD", "USD", "EUR"]; //Assiging values to drop down 
  $scope.ToCurrency = ["CAD", "USD", "EUR"];
  $scope.FrmamountSelected = function () {
var CurrFrmtVal=$scope.selectedFrmCurrency
var CurrTotVal=$scope.selectedToCurrency
if(CurrFrmtVal==CurrTotVal)
{
alert("Please select different currency"); // Condition alert:  check for the similar imputs.
$scope.ToAmount="";

}
else{

    $http({
      method: 'GET',
      url: 'http://api.fixer.io/latest?base='+CurrFrmtVal //Getting response from the JSON request
    }).then(function successCallback(response) {

      var results = response.data.rates[CurrTotVal];
      $scope.ToAmount=$scope.FrmAmount*results; // Extracting and manupulating the values ( Conversion)
      
    }, function errorCallback(response) {
    });
}


  }
   $scope.ToamountSelected = function () {
var CurrFrmtVal=$scope.selectedFrmCurrency
var CurrTotVal=$scope.selectedToCurrency
if(CurrFrmtVal==CurrTotVal)
{
alert("Please select different currency"); // Condition alert:  check for the similar imputs.
$scope.ToAmount="";

}
else{

    $http({
      method: 'GET',
      url: 'http://api.fixer.io/latest?base='+CurrFrmtVal //Getting response from the JSON request
    }).then(function successCallback(response) {

      var results = response.data.rates[CurrTotVal];
      $scope.ToAmount=$scope.FrmAmount*results; // Extracting and manupulating the values ( Conversion)
      
    }, function errorCallback(response) {
    });
}


  }
     $scope.linkClicked= function () {
     
      if($scope.myvalue==null)
      $scope.myvalue = "Note: Privileged/confidential information may be contained in this page and may be subject to legal privilege. Access to this application by anyone other than the intended is unauthorised. ";
      else
      $scope.myvalue=null;
  

  }

});